#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include <windows.h>
#include <glut.h>
#define pi (2*acos(0.0))

double cameraHeight;
double cameraAngle;
int drawgrid;
int drawaxes;
double angle;
double incx=50, incy;
int state;
double turn=0;
double isTurnNow;
double forward=0;
struct point
{
    double x,y,z;
};

void push_pop(void)
{
    glPushMatrix();
    glRotatef(50, 0, 0, 1);
    glPushMatrix(); // Furthest Triangle, Draw first
    //glRotatef(45, 0, 0, 1);
    glTranslatef(-20, 0, 0);
    //glScaled(2, 1, 0);
    glColor3f(0.0, 0.0, 1.0);
    glBegin(GL_POLYGON);
    glVertex2f(10, 10);
    glVertex2f(10, 0);
    glVertex2f(-10, 0);
    glEnd();
    glPopMatrix();

    glPushMatrix(); // Middle Triangle, Draw 2nd
    glColor3f(0.0, 1.0, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(10, 10);
    glVertex2f(10, 0);
    glVertex2f(-10, 0);
    glEnd();
    glPopMatrix();

    glPushMatrix(); // Nearest Triangle, Draw last
    glTranslatef(20, 0, 0);
    glColor3f(1.0, 0.0, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(10, 10);
    glVertex2f(10, 0);
    glVertex2f(-10, 0);
    glEnd();
    glPopMatrix();
    glPopMatrix();

}


void drawAxes()
{

    glColor3f(1.0, 1.0, 1.0);
    glBegin(GL_LINES);
    {
        glVertex3f( 100,0,0);
        glVertex3f(-100,0,0);

        glVertex3f(0,-100,0);
        glVertex3f(0, 100,0);

        glVertex3f(0,0, 100);
        glVertex3f(0,0,-100);
    }
    glEnd();

}


void drawGrid()
{
    int i;

    glColor3f(0.6, 0.6, 0.6);	//grey
    glBegin(GL_LINES);
    {
        for(i=-8; i<=8; i++)
        {

            if(i==0)
                continue;	//SKIP the MAIN axes

            //lines parallel to Y-axis
            glVertex3f(i*10, -90, 0);
            glVertex3f(i*10,  90, 0);

            //lines parallel to X-axis
            glVertex3f(-90, i*10, 0);
            glVertex3f( 90, i*10, 0);
        }
    }
    glEnd();

}

void drawSquare()
{
    //glColor3f(1.0,0.0,0.0);
    glBegin(GL_QUADS);
    {
        glVertex3f(2, 0,0);
        glVertex3f(-2, 0,0);
        glVertex3f(-2, -20,0);
        glVertex3f(2, -20,0);
    }
    glEnd();
}


void drawCircle(float radius_x, float radius_y)
{
    int i = 0;
    float angle = 0.0;

    glBegin(GL_POLYGON);
    {
        for(i = 0; i < 100; i++)
        {
            angle = 2 * 3.1416 * i / 100;
            glVertex3f (cos(angle) * radius_x, sin(angle) * radius_y, 0);
        }

    }

    glEnd();
}
void rec_animation()
{
    glColor3f(0,1,0);
    //glRotatef(3*angle,0,0,1);
    glTranslatef(incx,incy,0);
    glRotatef(10*angle,0,0,1);
//    drawSquare(5);

}
void draw_rec()
{
    glColor3f(0,1,0);

//    drawSquare(5);
}
void drawSS()
{
    glColor3f(1,0,0);
//    drawSquare(20);


    glPushMatrix();
    glRotatef(angle,0,0,1);  //kendro kore ghora
    glTranslatef(110,0,0);  //dure jawa
    glRotatef(2*angle,0,0,1); //nijer okkhe
    glColor3f(0,1,0); //jonmo newa
//    drawSquare(15);

    //glPopMatrix();

    glPushMatrix();
    glRotatef(angle,0,0,1);
    glTranslatef(60,0,0);
    glRotatef(2*angle,0,0,1);
    glColor3f(0,0,1);
//    drawSquare(10);
    glPopMatrix();

    glRotatef(4*angle,0,0,1);
    glTranslatef(55,0,0);
    glRotatef(2*angle,0,0,1);
    glColor3f(1,0,1);
//    drawSquare(10);
    glPopMatrix();


    glRotatef(3*angle,0,0,1);
    glTranslatef(50,0,0);
    //glRotatef(2*angle,0,0,1);
    glColor3f(0,1,1);
//    drawSquare(8);


    glRotatef(angle,0,0,1);
    glTranslatef(20,0,0);
    //glRotatef(angle/2,0,0,1);
    glColor3f(1.5,1,1);
//    drawSquare(5);

}



void ghonta()
{

    glTranslatef(incx,incy,0);
    glColor3f(1.0, 0.0, 0.0);
    //drawSquare();
    if(incx>40)
    {
        glRotatef(50*angle,0,0,1);
        glTranslatef(20, 0, 0);
//        drawSquare(5);
    }
}


void simple_trans()
{
    glRotatef(45, 0, 0, 1);
//    glTranslatef(-10, 0, 0);
//    glColor3f(0.0, 1.0, 0.0);
    draw_rec();
    glRotatef(45, 0, 0, 1);
    glTranslatef(-20, 0, 0);
//    glColor3f(1.0, 0.0, 0.0);
    draw_rec();
}



void lefthand()
{

}


void man()
{

    glTranslated(forward,0,0);

    ///head
    glPushMatrix();
    glTranslatef(0,33,0);
    glColor3f(1,0,1);
    glRotatef(turn, 0, 1, 0);
    drawCircle(9,9);
    glPopMatrix();


    ///body
    glPushMatrix();

    glRotatef(turn, 0, 1, 0);
    glColor3f(1,0,0);

    glBegin(GL_QUADS);
    {
        glVertex3f(2, 30,0);
        glVertex3f(-2, 30,0);
        glVertex3f(-2, -10,0);
        glVertex3f(2, -10,0);
    }
    glEnd();
    glPopMatrix();


    ///right hand
    glPushMatrix();
    glTranslatef(0,30,0);
    glRotatef(incx,0,0,1);
    glColor3f(1,1,1);
    glRotatef(turn, 0, 1, 0);
    drawSquare();
    glPopMatrix();

    ///left hand
    glPushMatrix();
    glTranslatef(0,30,0);
    glRotatef(-incx,0,0,1);
    glColor3f(0,1,0);
    glRotatef(turn, 0, 1, 0);
    drawSquare();
    glPopMatrix();

    ///right leg
    glPushMatrix();
    glTranslatef(0,-10,0);
    glRotatef(incx,0,0,1);
    glColor3f(1,1,1);
    glRotatef(turn, 0, 1, 0);
    drawSquare();
    glPopMatrix();

    ///left leg
    glPushMatrix();
    glTranslatef(0,-10,0);
    glRotatef(-incx,0,0,1);
    glColor3f(0,1,0);
    glRotatef(turn, 0, 1, 0);
    drawSquare();
    glPopMatrix();


}

void display()
{

    //clear the display
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glClearColor(0,0,0,0);	//color black
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


    //load the correct matrix -- MODEL-VIEW matrix
    glMatrixMode(GL_MODELVIEW);

    //initialize the matrix
    glLoadIdentity();

    //now give three info
    //1. where is the camera (viewer)?
    //2. where is the camera looking?
    //3. Which direction is the camera's UP direction?

    //gluLookAt(100,100,100,	0,0,0,	0,0,1);
    //gluLookAt(200*cos(cameraAngle), 200*sin(cameraAngle), cameraHeight,		0,0,0,		0,0,1);
    gluLookAt(0,0,200,	0,0,0,	0,1,0);


    //again select MODEL-VIEW
    glMatrixMode(GL_MODELVIEW);



    //add objects

    //drawAxes();
    //drawGrid();
    //drawCircle(10,10);
    //drawSS();
    //draw_rec();
    //push_pop();
    //simple_trans();
    //rec_animation();
    //ghonta();

    man();






    //ADD this line in the end --- if you use double buffer (i.e. GL_DOUBLE)
    glutSwapBuffers();
}


void animate()
{
    //rotation
    angle=0;
    //forward-=0.002;

    ///walking and rotation here
    if (forward<=0 && forward <50)
    {
        isTurnNow=1;
    }

    else if(forward >50)
    {
        isTurnNow=2;
        if(turn<180)
        {
            turn=turn+0.015;
        }
        else
        {
            isTurnNow=0;
        }

    }


    if (isTurnNow==1)
    {
        forward+=0.015;
    }
    else if(isTurnNow==2)
    {
        forward=forward;
    }
    else if(isTurnNow==0)
    {
        forward-=0.015;
    }






    //codes for any changes in Models, Camera
    //linear_oscillation

    if(state ==0 && incx>30 )
    {
        state =1;
    }
    if(state ==1 && incx <-30 )
    {
        state =0;
    }

    if(state == 0)
        incx+=0.045;
    else
        incx-=0.045;

    glutPostRedisplay();
}

void init()
{
    //codes for initialization
    drawgrid=0;
    drawaxes=1;
    cameraHeight=150.0;
    cameraAngle=1.0;
    angle=0;

    //clear the screen
    glClearColor(0,0,0,0);


    //load the PROJECTION matrix
    glMatrixMode(GL_PROJECTION);

    //initialize the matrix
    glLoadIdentity();

    //give PERSPECTIVE parameters
    gluPerspective(80,	1,	1,	1000.0);
    //field of view in the Y (vertically)
    //aspect ratio that determines the field of view in the X direction (horizontally)
    //near distance
    //far distance
}

int main(int argc, char **argv)
{
    glutInit(&argc,argv);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(0, 0);
    glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB);	//Depth, Double buffer, RGB color

    glutCreateWindow("My OpenGL Program");

    init();

    glEnable(GL_DEPTH_TEST);	//enable Depth Testing

    glutDisplayFunc(display);	//display callback function
    glutIdleFunc(animate);		//what you want to do in the idle time (when no drawing is occuring)

    //glutKeyboardFunc(keyboardListener);
    //glutSpecialFunc(specialKeyListener);
    //glutMouseFunc(mouseListener);

    glutMainLoop();		//The main loop of OpenGL

    return 0;
}


